#!/bin/sh

KEXT="com.apple.driver.AppleCameraInterface"

for ((i=0; i < 60 ; i++)); do
 if kextstat -l -b "$KEXT" | grep -q "$KEXT" ; then
  syslog -s -l notice "$0: Unloading kext"
  kextunload -b "$KEXT"
  exit 0
 fi

 syslog -s -l notice "$0: Waiting for kext load"
 sleep 5
done

syslog -s -l notice "$0: Timeout"

